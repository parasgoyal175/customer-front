package com.example.demo.controller;
import com.example.demo.model.Admin;
import com.example.demo.request.LoginRequest;
import com.example.demo.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class adminController {

    @Autowired
    AdminService adminservice;

    @PostMapping("/addUser")
    @CrossOrigin(origins = "http://localhost:5173")
    public Admin addUser(@RequestBody Admin user){
        return adminservice.addUser(user);
    }

    @PostMapping("/loginUser")
    @CrossOrigin(origins = "http://localhost:5173")
    public Boolean loginuser(@RequestBody LoginRequest loginrequest){
        return adminservice.loginUser(loginrequest);
    }
}
