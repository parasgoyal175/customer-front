//package com.example.demo.controller;
//
//import com.example.demo.exception.userNotFoundException;
//import com.example.demo.model.User;
//import com.example.demo.repository.UserRepo;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.*;
////import org.springframework.web.bind.annotation.CrossOrigin;
//
//import java.nio.file.attribute.UserPrincipalNotFoundException;
//import java.util.List;
//
//@RestController
//@CrossOrigin("http://localhost:5173")
//public class userController {
//
//    @Autowired
//    private UserRepo userRepository;
//
//    @PostMapping("/user")
//    public User newUser (@RequestBody User newUser){
//        return userRepository.save(newUser);
//    }
//
//    @GetMapping("/users")
//    List<User> getAllUsers(){
//        return userRepository.findAll();
//    }
//
//    @GetMapping("/user/{id}")
//    User getUserById(@PathVariable Long id){
//        return userRepository.findById(id)
//                .orElseThrow(()-> new userNotFoundException(id));
//    }
//
//    @PutMapping("/user/{id}")
//    User updateUser(@RequestBody User newUser, @PathVariable Long id){
//        return userRepository.findById((id))
//                .map(user -> {
//                    user.setUsername(newUser.getUsername());
//                    user.setName(newUser.getName());
//                    user.setEmail(newUser.getEmail());
//                    return userRepository.save(user);
//                }).orElseThrow(()-> new userNotFoundException(id));
//    }
//
//    @DeleteMapping("/user/{id}")
//    String deleteUser(@PathVariable Long id){
//        if(!userRepository.existsById(id)){
//            throw new userNotFoundException(id);
//        }
//        userRepository.deleteById(id);
//        return "User with id "+id +" has been deleted successfully";
//    }
//
//}
package com.example.demo.controller;
import com.example.demo.model.User;
import com.example.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@CrossOrigin("http://localhost:5173")
public class UserController {

    @Autowired
    private UserService userservice;

    @PostMapping("/user")
    public User newUser(@RequestBody User newUser) {
        return userservice.saveUser(newUser);
    }

    @GetMapping("/users")
    public List<User> getAllUsers() {
        return userservice.getAllUsers();
    }

    @GetMapping("/user/{id}")
    public User getUserById(@PathVariable Long id) {
        return userservice.getUserById(id);
    }

    @PutMapping("/user/{id}")
    public User updateUser(@RequestBody User newUser, @PathVariable Long id) {
        return userservice.updateUser(newUser, id);
    }

    @DeleteMapping("/user/{id}")
    public String deleteUser(@PathVariable Long id) {
        return userservice.deleteUser(id);
    }
}

