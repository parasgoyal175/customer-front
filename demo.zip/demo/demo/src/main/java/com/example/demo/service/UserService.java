package com.example.demo.service;
import com.example.demo.exception.userNotFoundException;
import com.example.demo.model.User;
import com.example.demo.repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class UserService {

    @Autowired
    private UserRepo userrepo;
    public User saveUser(User newUser) {
        return userrepo.save(newUser);
    }
    public List<User> getAllUsers() {
        return userrepo.findAll();
    }

    public User getUserById(Long id) {
        return userrepo.findById(id)
                .orElseThrow(() -> new userNotFoundException(id));
    }

    public User updateUser(User newUser, Long id) {
        return userrepo.findById(id)
                .map(user -> {
                    user.setUsername(newUser.getUsername());
                    user.setName(newUser.getName());
                    user.setEmail(newUser.getEmail());
                    return userrepo.save(user);
                }).orElseThrow(() -> new userNotFoundException(id));
    }

    public String deleteUser(Long id) {
        if (!userrepo.existsById(id)) {
            throw new userNotFoundException(id);
        }
        userrepo.deleteById(id);
        return "User with id " + id + " has been deleted successfully";
    }
}
