package com.example.demo.service;
import com.example.demo.model.Admin;
import com.example.demo.repository.AdminRepo;
import com.example.demo.request.LoginRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service
public class AdminService {

    @Autowired
    private AdminRepo adminRepo;

    public Admin addUser(Admin user){
        return adminRepo.save(user);
    }

    public Boolean loginUser(LoginRequest loginRequest) {
        Optional<Admin> user = adminRepo.findById(loginRequest.getUserId());

        if (user.isEmpty()) {
            return false;
        }

        Admin user1 = user.get();
        return user1.getPassword().equals(loginRequest.getPassword());
    }
}
