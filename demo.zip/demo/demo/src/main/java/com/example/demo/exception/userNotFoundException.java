package com.example.demo.exception;

public class userNotFoundException extends RuntimeException{

    public userNotFoundException( Long id){
        super("could not found user with id: " + id);
    }
}
